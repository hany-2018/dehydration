<?php
include_once 'Admin/connection.php';

include_once 'includes/temp/header.php'
?>

    <!-- Services Start -->
<div class="section-full bg-white content-inner">
    <div class="container">
        <div class="section-head text-center ">
            <h3 class="h3 text-uppercase"><span class="text-primary">


                    <?php
                    $stmt = $con->prepare("SELECT what_title FROM dehydration");
                    $stmt->execute();
                    $about_heading = $stmt->fetch();
                    print_r($about_heading[0]);
                    ?>

                </span> </h3>
<!--            <p>Dehydration occurs when you use or lose more fluid than you take in, and your body doesn't have enough-->
<!--                water and other fluids to carry out its normal functions. If you don't replace lost fluids, you will get-->
<!--                dehydrated</p>-->
<!--            <p>Anyone may become dehydrated, but the condition is especially dangerous for young children and older-->
<!--                adults</p>-->
<!--            <p>The most common cause of dehydration in young children is severe diarrhea and vomiting. Older adults-->
<!--                naturally have a lower volume of water in their bodies, and may have conditions or take medications that-->
<!--                increase the risk of dehydration.</p>-->
<!--            <p>This means that even minor illnesses, such as infections affecting the lungs or bladder, can result in-->
<!--                dehydration in older adults.</p>-->
<!--            <p>Dehydration also can occur in any age group if you don't drink enough water during hot weather —-->
<!--                especially if you are exercising vigorously.</p>-->
<!--            <p>You can usually reverse mild to moderate dehydration by drinking more fluids, but severe dehydration-->
<!--                needs immediate medical treatment.</p>-->
            <span style="line-height: 30px">
                <p>
            <?php
            $stmt = $con->prepare("SELECT what_paragraph FROM dehydration");
            $stmt->execute();
            $about_heading = $stmt->fetch();
            print_r($about_heading[0]);
            ?>
            </span>
            </p>

        </div>
        <div class="section-content ">
            <div class="container">
                <div class="row">
                    <h3 class="h3 text-center"><span class="text-primary">

                                    <?php
                                    $stmt = $con->prepare("SELECT symptoms_title FROM dehydration");
                                    $stmt->execute();
                                    $about_heading = $stmt->fetch();
                                    print_r($about_heading[0]);
                                    ?>


                        </span></h3>
                    <span style="line-height: 30px; text-align: center">
                        <p>
                        <?php
                        $stmt = $con->prepare("SELECT symptoms_paragraph FROM dehydration");
                        $stmt->execute();
                        $about_heading = $stmt->fetch();
                        print_r($about_heading[0]);
                        ?>
                        </p>


                    </span>
                </div>
            </div>
            <div class="col-md-6 col-sm-6 m-b30">
                <div class="dez-box dehy_photo">
                    <div class="dez-media"><a href="#"><img src="Admin/uploads/dehydration/<?php

                                $stmt = $con->prepare("SELECT image FROM dehydration_block WHERE id = 1");
                                $stmt->execute();
                                $about_heading = $stmt->fetch();
                                print_r($about_heading[0]);

                            ?>" alt="" height="350px" width="556px"></a>
                    </div>
                    <div class="dez-info p-a30 border-1">
                        <h4 class="dez-title m-t0"><a href="#">

                                <?php
                                $stmt = $con->prepare("SELECT title FROM dehydration_block WHERE id = 1");
                                $stmt->execute();
                                $about_heading = $stmt->fetch();
                                print_r($about_heading[0]);
                                ?>

                            </a></h4>
                        <div class="dez-separator bg-primary"></div>
                        <p class="m-b15 text-center" style="width: 100%;">
                        <?php
                        $stmt = $con->prepare("SELECT paragraph FROM dehydration_block WHERE id = 1");
                        $stmt->execute();
                        $about_heading = $stmt->fetch();
                        print_r($about_heading[0]);
                        ?>
                        </p>
<!--                        <p class="m-b15">• Dry mouth and tongue <br>-->
<!--                            • No tears when <br>-->
<!--                            • No wet diapers for three hours <br>-->
<!--                            • Sunken eyes, cheeks <br>-->
<!--                            • Sunken soft spot on top of skull <br>-->
<!--                            • Listlessness or irritability <br>-->
<!--                        </p>-->
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-sm-6 m-b30">
                <div class="dez-box dehy_photo">
                    <div class="dez-media"><a href="#"><img src="Admin/uploads/dehydration/<?php

                        $stmt = $con->prepare("SELECT image FROM dehydration_block WHERE id = 2");
                        $stmt->execute();
                        $about_heading = $stmt->fetch();
                        print_r($about_heading[0]);

                            ?>" alt="" height="350px" width="556px"></a>
                    </div>
                    <div class="dez-info p-a30 border-1">
                        <h4 class="dez-title m-t0"><a href="#">

                                <?php
                                $stmt = $con->prepare("SELECT title FROM dehydration_block WHERE id = 2");
                                $stmt->execute();
                                $about_heading = $stmt->fetch();
                                print_r($about_heading[0]);
                                ?>


                            </a></h4>
                        <div class="dez-separator bg-primary"></div>
                        <p class="m-b15 text-center" style="width: 100%">
                            <?php
                            $stmt = $con->prepare("SELECT paragraph FROM dehydration_block WHERE id = 2");
                            $stmt->execute();
                            $about_heading = $stmt->fetch();
                            print_r($about_heading[0]);
                            ?>


                        </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-offset-3 col-md-6 col-sm-6 m-b30">
                    <div class="dez-box dehy_photo">
                        <div class="dez-media"><a href="#"><img src="Admin/uploads/dehydration/<?php

                        $stmt = $con->prepare("SELECT image FROM dehydration_block WHERE id = 3");
                        $stmt->execute();
                        $about_heading = $stmt->fetch();
                        print_r($about_heading[0]);

                                ?>" alt="" height="350px" width="556px"></a>
                        </div>
                        <div class="dez-info p-a30 border-1">
                            <h4 class="dez-title m-t0"><a href="#">

                                    <?php
                                    $stmt = $con->prepare("SELECT title FROM dehydration_block WHERE id = 3");
                                    $stmt->execute();
                                    $about_heading = $stmt->fetch();
                                    print_r($about_heading[0]);
                                    ?>


                                </a></h4>
                            <div class="dez-separator bg-primary"></div>
                            <p class="m-b15 text-center"style="width: 100%">

                                <?php
                                $stmt = $con->prepare("SELECT paragraph FROM dehydration_block WHERE id = 3");
                                $stmt->execute();
                                $about_heading = $stmt->fetch();
                                print_r($about_heading[0]);
                                ?>


                            </p>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>
</div>
</div>
<!-- Services END -->
<?php
include_once 'includes/temp/footer.php'
?>