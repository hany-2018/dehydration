<?php
include 'connection.php';
include 'includes/temp/leftSideBar.php';
include 'includes/temp/header.php'
?>


    <style>
        .edit-btn {
            color: #1d9413;
            position: relative;
            top: 60px;
        }
    </style>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Kids us lite
            </h1>
        </section>

        <!-- Main content -->
        <section class="content">

            <div class="row">
                <!-- /.col -->
                <div class="col-md-12">
                    <!-- /.nav-tabs-custom -->

                    <div class="callout callout-default" style="border: 1px solid #bbbbbb">
                        <h4>

                            <table class="table table-bordered">
                                <tbody>
                                <tr>
                                    <!--                                    <th style="width: 10px">id</th>-->
                                    <th>Image</th>
                                    <th>Title</th>
                                    <th style="width: 40px">Paragraph</th>
                                    <th>Action</th>
                                </tr>


                                <?php

                                $stmt = $con->prepare("SELECT * FROM kidsuslite");
                                $stmt->execute();
                                $rows = $stmt->fetchAll();
                                foreach ($rows as $row) {
                                    ?>
                                    <tr>


                                        <form action="update_Kidsuslite.php?&id=<?php echo $row['id']?>"
                                              method="post">
                                            <td>
                                                <input type="hidden" value="<?php echo $row['id']?>" >
<!--                                                <img src="uploads/kiduslite/--><?php //echo $row['image']?><!--" alt=""-->
<!--                                                     width="150px" height="100px"-->
<!--                                                     style="border:1px solid #b1b1b1 ;border-radius: 30px">-->
                                                <img src="uploads/kiduslite/<?php echo $row['image']?>" width="150px" height="100px"
                                                style="border: 1px solid #b1b1b1; border-radius: 30px">
                                            </td>



                                            <td>
                                                <?php echo $row['title']?>
                                            </td>
                                            <td>
                                                <?php echo $row['paragraph']?>
                                            </td>
                                            <td>
                                        <span>
                                                <a href="update_Kidsuslite.php?id=<?php echo $row['id'] ?>"><i
                                                        class="fa fa-edit fa-2x edit-btn" style="color: #1d9413"></i></a>
                                        </span>
                                            </td>
                                        </form>
                                    </tr>


                                    <?php
                                }
                                ?>

                                </tbody>
                            </table>


                            <!--                            --><?php
                            //                            } ?>


                            <!--                        <div class="btn btn-primary"><a href="update_home.php?id=edit">Edit</a></div>-->


                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->

        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->


    <!-- Control Sidebar -->
    <!-- /.control-sidebar -->
    <!-- Add the sidebar's background. This div must be placed
         immediately after the control sidebar -->
    <div class="control-sidebar-bg"></div>

    <!-- ./wrapper -->

    <!-- jQuery 3 -->
    <!--<script src="bower_components/jquery/dist/jquery.min.js"></script>-->
    <!-- Bootstrap 3.3.7 -->
    <script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>-->
    <!-- FastClick -->
    <!--<script src="bower_components/fastclick/lib/fastclick.js"></script>-->
    <!--<!-- AdminLTE App -->
    <!--<script src="dist/js/adminlte.min.js"></script>-->
    <!-- AdminLTE for demo purposes -->
    <!--<script src="dist/js/demo.js"></script>-->

<?php
include 'includes/temp/footer.php'
?>