<?php
include 'connection.php';
include 'includes/temp/leftSideBar.php';
include 'includes/temp/header.php'
?>

<?php
/*
 * Manage member page
 *you can add | edit | delete member from here
 *
 * */

$pageTitle = 'Member';
if (isset($_POST['submit'])) {


    $do = isset($_GET['do']) ? $_GET['do'] : 'Manage';

    //=================================================================================================================
    //manage page
//    if ($do == 'manage') {
//        // show active button just only pending user
//        $query = '';
//
//        if(isset($_GET['page']) && $_GET['page'] == 'pending'){
//            $query = 'AND regStatus = 0';
//        }
//        // ************************************************************************test check item function
//        //*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/
////        $value='nasr';
////        $check = checkItem('userName','users',$value);
////        if($check == 1){
////            echo"exist";
////        }
//        // fetch all user data from db except admin - admin = 1
//        $stmt = $con->prepare("SELECT*FROM users WHERE groupId !=1 $query ORDER BY id DESC");
//        //execute the statement
//        $stmt->execute();
//        //assign to variable
//        $rows = $stmt->fetchAll();
//        ?>
<!---->
<!--        <h1 class='text-center'> Welcome to Manage Members</h1>-->
<!--        <div class='container'>-->
<!--            <div class="table-responsive">-->
<!--                <table class="table table-bordered main-table ">-->
<!--                    <tr>-->
<!--                        <td style="letter-spacing: 3px">ID</td>-->
<!--                        <td style="letter-spacing: 3px">Username</td>-->
<!--                        <td style="letter-spacing: 3px">Email</td>-->
<!--                        <td style="letter-spacing: 3px">Full Name</td>-->
<!--                        <td style="letter-spacing: 3px">Register Date</td>-->
<!--                        <td style="letter-spacing: 3px">Control</td>-->
<!--                    </tr>-->
<!--                    --><?php
//                    foreach ($rows as $row) {
//                        echo "<tr>";
//                        echo "<td class='text-center'>" . $row['id'] . "</td>";  // column name in table in DB
//                        echo "<td class='text-center'>" . $row['userName'] . "</td>";
//                        echo "<td class='text-center'>" . $row['email'] . "</td>";
//                        echo "<td class='text-center'>" . $row['fullName'] . "</td>";
//                        echo "<td class='text-center'>" . $row['date'] . "</td>";
//                        echo "<td class='text-center'>
//                            <a href=members.php?do=edit&id=" . $row['id'] . "><div class='btn btn-success'><i class='fa fa-edit'></i>Edit</div></a>
//                            <a href=members.php?do=delete&id=" . $row['id'] . "><div class='btn btn-danger confirm'><i class='fa fa-close'></i>Delete</div></a>
//                                                       ";
//                        if($row['regStatus'] ==0){
//                            echo"<a href=members.php?do=active&id=" . $row['id'] . "><div class='btn btn-info'>
//                                <i class='fa fa-check'></i>active</div></a></td>";
//
//                        }
//                        echo"</tr>";
//
//                    } ?>
<!---->
<!--                </table>-->
<!--            </div>-->
<!--            <div class='new-member btn btn-primary'><i class="fa fa-plus"></i><a href='members.php?do=add'>&nbsp Add New member</a>-->
<!--            </div>-->
<!--        </div>-->

        <?php

//==================================================================================================================
        //add page
//    } elseif ($do == 'add') { ?>
<!--        <div class="container">-->
<!--            <h1 class='text-center'> Add Member</h1>-->
<!---->
<!--            <form class="form-horizontal" action="members.php?do=insert" method="POST">-->
<!--                <div class="form-group">-->
<!---->
<!--                    <label class="col-sm-2 control-label">Username</label>-->
<!--                    <div class="col-sm-10 col-md-8">-->
<!--                        <input type="text" name="username" class="form-control"-->
<!--                               autocomplete="off" required="required">-->
<!--                    </div>-->
<!--                </div>-->
<!---->
<!--                <div class="form-group">-->
<!--                    <label class="col-sm-2 control-label">Password</label>-->
<!--                    <div class="col-sm-10 col-md-8">-->
<!---->
<!--                        <input type="password" name="password" class="password form-control"-->
<!--                               placeholder="password must be complex" autocomplete="new-password" required="required">-->
<!--                        <i class="show-pass fa fa-eye"></i>-->
<!--                    </div>-->
<!--                </div>-->
<!---->
<!--                <div class="form-group">-->
<!--                    <label class="col-sm-2 control-label">E-mail</label>-->
<!--                    <div class="col-sm-10 col-md-8">-->
<!--                        <input type="email" name="mail" class="form-control"-->
<!--                               placeholder="mail must be valid" required="required">-->
<!--                    </div>-->
<!--                </div>-->
<!---->
<!--                <div class="form-group">-->
<!--                    <label class="col-sm-2 control-label">Full Name</label>-->
<!--                    <div class="col-sm-10 col-md-8">-->
<!--                        <input type="text" name="full_name" class="form-control"-->
<!--                               placeholder="Full Name appear in profile page " required="required">-->
<!--                    </div>-->
<!--                </div>-->
<!---->
<!--                <div class="form-group">-->
<!---->
<!--                    <div class="col-sm-10 col-lg-offset-2 col-md-8 col-md-offset-2">-->
<!--                        <input type="submit" name="edit" class="btn btn-primary btn-block" value="Add Member">-->
<!--                    </div>-->
<!--                </div>-->
<!---->
<!--            </form>-->
<!---->
<!--        </div>-->
<!--        --><?php
//        //==================================================================================================================
//        ?>
<!--        --><?php //                                                                                          //insert page
//    } elseif ($do == 'insert') {
//
//
//        $formError = array();
//        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
//
//            echo "<h1 class='text-center'>welcome to update page</h1>";
//            echo "<div class='container'>";
//
//
//            $user = $_POST['username'];
//            $pass = $_POST['password'];
//            $email = $_POST['mail'];
//            $full = $_POST['full_name'];
//
//            // hash password
//            $hashpass = sha1($_POST['password']);
//
//            // validation form
//            if (empty($user)) {
//                $formError[] = "username field is empty";
//            }
//            if (strlen($user) < 4) {
//                $formError[] = "Username can't less than 4 character";
//            }
//            if (strlen($user) > 20) {
//                $formError[] = "Username can't more than 20 character";
//            }
//            if (empty($pass)) {
//                $formError[] = "Password field is empty";
//            }
//            if (empty($email)) {
//                $formError[] = "mail field is empty";
//            }
//            if (empty($full)) {
//                $formError[] = "username field is empty";
//            }
//            if (strlen($full) < 4) {
//                $formError[] = "Full Name can't less than 4 character";
//            }
//            if (strlen($full) > 20) {
//                $formError[] = "Full Name can't more than 20 character";
//            }
//
//            foreach ($formError as $error) {
//                echo "<div class='container alert alert-danger text-danger'>" . $error . "</div>";
//            }
//
//            if (empty($formError)) {
//                // check username in database
//                $check = checkItem('userName','users',$user);
//                if($check == 1){
//                    echo "<div class='container alert alert-danger'>sorry you entered username exist</div>";
//                }else {
//                    //insert user info in database
//                    $stmt = $con->prepare("INSERT INTO users(userName,password,email,fullname,	regStatus,date)
//                                        VALUES(:zuser, :zpass, :zemail, :zfull,1,now());");//DB
//                    $stmt->execute(array(
//                        'zuser' => $user,
//                        'zpass' => $hashpass,
//                        'zemail' => $email,
//                        'zfull' => $full
//                    ));
//
//                    $Msg = "<h5 class='container alert alert-success text-success'>" . $stmt->rowCount() . " Record Inserted</h5>";
//                    redirectIndex($Msg,3);
//                }
//            }
////
////            // update the database with this info
////
////
//        } else {
//            $Msg = "<div class='container alert alert-danger'>Sorry You Can't Browse This Page Directly</div>";
//            redirectIndex($Msg,'back',3);
//            echo "</div>";
//            //==================================================================================================================
//        }

    if ($do == 'edit') {                                                                              // edit page
        // check if  GET REQUEST is numeric get integer value on it
        $id = (isset($_GET['id']) && is_numeric($_GET['id'])) ? intval($_GET['id']) : 0;
        // select all data depend on id
        $stmt = $con->prepare('SELECT * FROM dehydration_block WHERE id = ?');
        //  execute query
        $stmt->execute(array($id));
        // fetch data of query
        $row = $stmt->fetch();
        // the row count
        $count = $stmt->rowCount();
        // if there is such id show form
        if ($stmt->rowCount() > 0) {
            echo "this is data for user"; ?>

            <h1 class="text-center"> Edit Member</h1>
            <div class="container">
                <div class="text-center"
                "welcome to edit page"
            </div>;
            <form class="form-horizontal" action="update_dehydration_block.php?do=update" method="POST">
                <div class="form-group">
                    <input type="hidden" name="id" value="<?php echo $id ?>">
                    <label class="col-sm-2 control-label">Image</label>
                    <div class="col-sm-10 col-md-8">
                        <input type="image" name="image" value="<?php echo $row['image'] // col DB ?>" class="form-control"
                               autocomplete="off" required="required">
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-2 control-label">title</label>
                    <div class="col-sm-10 col-md-8">
                        <input type="text" name="title" value="<?php echo $row['title'] // col DB ?>">
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-2 control-label">Paragraph</label>
                    <div class="col-sm-10 col-md-8">
                        <input type="text" name="paragraph" value="<?php echo $row['paragraph'] // col DB?>" class="form-control"
                               required="required">
                    </div>
                </div>

            </form>
            </div>
        <?php
        } else {
            $errorMsg = "<div class='container alert alert-danger'>there is no such id</div>";
            redirectIndex($errorMsg,3);
        }

        //==================================================================================================================

//    } elseif ($do == 'update') {                                                                    // update page
//        echo "<h1 class='text-center'>welcome to update page</h1>";
//        echo "<div class='container'>";
//
//        $formError = array();
//        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
//            $id = $_POST['id'];
//            $image = $_POST['image'];
//            // password for trick
//            $title = $_POST['title'];
//            $paragraph = $_POST['paragraph'];
//
//            // trick password
//            $pass = '';
//            if (empty($_POST['newpassword'])) {
//                $pass = $_POST['oldpassword'];
//            } else {
//                $pass = sha1($_POST['newpassword']);
//            }
//            // validation form
//            if (empty($user)) {
//                $formError[] = "username field is empty";
//            }
//            if (strlen($user) < 4) {
//                $formError[] = "Username can't less than 4 character";
//            }
//            if (strlen($user) > 20) {
//                $formError[] = "Username can't more than 20 character";
//            }
//            if (empty($email)) {
//                $formError[] = "mail field is empty";
//            }
//            if (empty($full)) {
//                $formError[] = "username field is empty";
//            }
//            if (strlen($full) < 4) {
//                $formError[] = "Full Name can't less than 4 character";
//            }
//            if (strlen($full) > 20) {
//                $formError[] = "Full Name can't more than 20 character";
//            }
//
//            foreach ($formError as $error) {
//                echo "<div class='alert alert-danger text-danger'>" . $error . "</div>";
//            }
//
//            if (empty($formError)) {
//
//                $stmt2 = $con->prepare("SELECT
//                                                        *
//                                                  FROM
//                                                        users
//                                                  WHERE
//                                                        userName = ?
//                                                  AND id =?");
//                $stmt2->execute(array($user,$id));
//                $count = $stmt2->rowCount();
//                if($count ==1){
//                    echo "<div class='container alert alert-danger'>This user is exist</div>";
//                }else{
//                    $stmt = $con->prepare('UPDATE users SET userName = ? , password = ? , email = ? ,fullname = ? WHERE id = ?');
//                    $stmt->execute(array($user, $pass, $email, $full, $id));  // same arrange stmt sql parameter and variable array
////
////                    // echo success message
//                    $Msg =  "<h5 class='container alert alert-success text-success'>" . $stmt->rowCount() . "User Updated</h5>";
//                    redirectIndex($Msg,'back',4);
//                }
//
//
//            }
//
//            // update the database with this info
//
//
//        } else {
//            $Msg = "<div class='container alert alert-danger'>Sorry You Can't Browse This Page Directly</div>";
//            redirectIndex($Msg,4);
//            echo "</div>";
//        }
//
////======================================================================================================================
//        //Delete page
//    } elseif ($do == 'delete') {    ?>
<!--        <div class="container">-->
<!--        <h1 class="text-center">welcome to Delete Member</h1>-->
<!--        --><?php
//        // check if  GET REQUEST is numeric get integer value on it
//        $id = (isset($_GET['id']) && is_numeric($_GET['id'])) ? intval($_GET['id']) : 0;
//        // select all data depend on id
//        $stmt = $con->prepare("SELECT * FROM users WHERE id = ?");
//        //  execute query
//        $stmt->execute(array($id));
//        // the row count
//        $count = $stmt->rowCount();
//        // if there is such id show form
//        if ($stmt->rowCount() > 0) {
//
//            $stmt = $con->prepare('DELETE FROM users WHERE id = :zid');
//            $stmt->bindParam(':zid', $id);
//            $stmt->execute();
//            $Msg =  "<h5 class='container alert alert-success text-success'>" . $stmt->rowCount() . " User Deleted</h5>";
//            redirectIndex($Msg,'back',3);
//        }
//        else {
//            $Msg = "<div class='container alert alert-danger'>This ID is not exist</div>";
//            redirectIndex($Msg,3);
//            echo"</div>";
//        }
//    }elseif ($do == 'active') {?>
<!--        <div class="container">-->
<!--            <h1 class="text-center">welcome to Active Member</h1>-->
<!--        --><?php
//        // check if  GET REQUEST is numeric get integer value on it
//        $id = (isset($_GET['id']) && is_numeric($_GET['id'])) ? intval($_GET['id']) : 0;
//        // select all data depend on id
//        $stmt = $con->prepare("SELECT * FROM users WHERE id = ?");
//        //  execute query
//        $stmt->execute(array($id));
//        // the row count
//        $count = $stmt->rowCount();
//        // if there is such id show form
//        if ($stmt->rowCount() > 0) {
//
//            $stmt = $con->prepare('UPDATE users SET regStatus = 1 WHERE id = :zid');
//            $stmt->bindParam(':zid', $id);
//            $stmt->execute();
//            $Msg = "<h5 class='container alert alert-success text-success'>" . $stmt->rowCount() . " User Activated</h5>";
//            redirectIndex($Msg,'back',3);
//        }
//        else {
//            $Msg = "<div class='container alert alert-danger'>This ID is not exist</div>";
//            redirectIndex($Msg,3);
//            echo"</div>";
//        }
    }
}
//else {
//    header('Location: index.php');
//    exit();
//}
//include $tpl.'footer.php';
//
//ob_end_flush();
?>

<?php
include 'includes/temp/footer.php'
?>