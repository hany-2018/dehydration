<?php
include 'connection.php';
include 'includes/temp/leftSideBar.php';
include 'includes/temp/header.php'
?>

    <!--detect id-->
<?php
$id = isset($_GET['id']) ? $_GET['id'] : 'not found id';

if($id = 'edit'){
    ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
               dehydration page
            </h1>
        </section>

        <!-- Main content -->
        <section class="content">

            <div class="row">
                <!-- /.col -->
                <div class="col-md-12">
                    <!-- /.nav-tabs-custom -->

                    <div class="callout callout-default" style="border: 1px solid #bbbbbb">
                        <h4>

                            <?php
                            $stmt = $con->prepare("SELECT what_title FROM dehydration");
                            $stmt->execute();
                            $about_heading = $stmt->fetch();
                            print_r($about_heading[0]);
                            ?>

                        </h4><br>

                        <p>

                            <?php
                            $stmt = $con->prepare("SELECT what_paragraph FROM dehydration");
                            $stmt->execute();
                            $about_heading = $stmt->fetch();
                            print_r($about_heading[0]);
                            ?>

                        </p><br>

                        <p>

                            <?php
                            $stmt = $con->prepare("SELECT symptoms_title FROM dehydration");
                            $stmt->execute();
                            $about_heading = $stmt->fetch();
                            print_r($about_heading[0]);
                            ?>

                        </p><br>

                        <p>

                            <?php
                            $stmt = $con->prepare("SELECT symptoms_paragraph FROM dehydration");
                            $stmt->execute();
                            $about_heading = $stmt->fetch();
                            print_r($about_heading[0]);
                            ?>

                        </p><br>

                        <span>
                                <a href="update_dehydration.php?id=edit"><i class="fa fa-edit fa-2x" style="color: #1d9413"></i></a>
                        </span>

                        <!--                        <div class="btn btn-primary"><a href="update_home.php?id=edit">Edit</a></div>-->

                        <?php
                        }
                        ?>

                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->

        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->


    <!-- Control Sidebar -->
    <!-- /.control-sidebar -->
    <!-- Add the sidebar's background. This div must be placed
         immediately after the control sidebar -->
    <div class="control-sidebar-bg"></div>

    <!-- ./wrapper -->

    <!-- jQuery 3 -->
    <!--<script src="bower_components/jquery/dist/jquery.min.js"></script>-->
    <!-- Bootstrap 3.3.7 -->
    <script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>-->
    <!-- FastClick -->
    <!--<script src="bower_components/fastclick/lib/fastclick.js"></script>-->
    <!--<!-- AdminLTE App -->
    <!--<script src="dist/js/adminlte.min.js"></script>-->
    <!-- AdminLTE for demo purposes -->
    <!--<script src="dist/js/demo.js"></script>-->

<?php
include 'includes/temp/footer.php'
?>