<?php include 'connection.php'?>
<?php
echo"<title>Contact Us</title>"?>
<?php include 'includes/temp/header.php' ?>


<?php //include 'includes/temp/header_pagination.php'?>
<?php include 'includes/temp/leftSideBar.php'?>

<!-- Left side column. contains the logo and sidebar -->


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Block Header
            <small>admin panal</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Block header</a></li>
            <!--                <li class="active">Data tables</li>-->
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <!-- /.box -->

                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">Block header </h3>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <table id="example1" class="table table-bordered table-striped" style="border: 1px solid #000">
                            <thead>
                            <tr>
                                <th>id</th>
                                <th>Title</th>
                                <th>Mobile</th>
                                <th>Name</th>
                                <th>Action</th>
                            </tr>
                            </thead>

                            <tbody>
                            <tr>
                                <?php
                                $stmt = $con->prepare("SELECT*FROM block_header");
                                $stmt->execute();
                                $rows = $stmt->fetchAll();
                                foreach ($rows as $row){
                                ?>

                                <td><?php echo $row['id']?></td>
                                <td><?php echo $row['title']?></td>
                                <td><?php echo $row['mobile']?></td>
                                <td><?php echo $row['name']?></td>
                                <td>
                                    <a href="update_block_header.php?id=<?php echo $row['id']?>">
                                        <div class="btn btn-success">
                                            <div class="fa fa-edit" style="color: #fff;"></div>
                                            Edit</div>
                                    </a>

                                </td>
                            </tr>
                            <?php   }

                            ?>
                        </table>

                        <nav aria-label="...">
                            <ul class="pagination">
                                <li class="page-item disabled">
                                    <a class="page-link" href="#" tabindex="-1">Previous</a>
                                </li>
                                <li class="page-item"><a class="page-link" href="#">1</a></li>
                                <li class="page-item active">
                                    <a class="page-link" href="#">2 <span class="sr-only">(current)</span></a>
                                </li>
                                <li class="page-item"><a class="page-link" href="#">3</a></li>
                                <li class="page-item">
                                    <a class="page-link" href="#">Next</a>
                                </li>
                            </ul>
                        </nav>


                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<!-- Add the sidebar's background. This div must be placed
     immediately after the control sidebar -->
<div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->


<!-- jQuery 2.2.3 -->
<?php //include 'includes/temp/footer_code_pagination.php'?>

<?php include 'includes/temp/footer.php'?>


