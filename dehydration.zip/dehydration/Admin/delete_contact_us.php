<?php
echo"<title>Delete Contact Us</title>";
include 'connection.php';
include 'includes/temp/header.php'?>

<?php
if(isset($_GET['id'])){
    $id = $_GET['id'];
    $stmt = $con->prepare('DELETE FROM contact_us WHERE id = :zid');
    $stmt->execute(array(
        'zid'=>$id
    ));
    echo "<script> location.href = '_contact_us.php'; </script>";
}?>


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Delete Contact Us
            <small>admin panal</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Delete contact us</a></li>
            <!--                <li class="active">Data tables</li>-->
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <!-- /.box -->

                <div class="box">

                    <!-- /.box-header -->
                    <div class="box-body">
                        <div class="container alert alert-success">
                            <a class="fa fa-check"></a>
                            Record Deleted Successfully
                        </div>
                        <?php
                        header('Location: contact_us.php');
                        ?>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php include 'includes/Templates/footer_pagination.php'?>

<!-- Control Sidebar -->
<!-- /.control-sidebar -->
<?php include 'includes/Templates/sidebar.php'?>
<!-- Add the sidebar's background. This div must be placed
     immediately after the control sidebar -->
<div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 2.2.3 -->
<?php include 'includes/Templates/footer_code_pagination.php'?>
