<?php
//template directory
$tpl = 'includes/temp/';

?>