<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel">
            <div class="pull-left image">
                <img src="dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
                <p><?php echo 'welcome admin'?></p>
                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
        </div>
        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu" data-widget="tree">
            <li class="header">MAIN NAVIGATION</li>

            <li>
                <a href="_block_header.php">
                    <i class="fa fa-dashboard"></i> <span>block header</span>
                    <span class="pull-right-container">
            </span>
                </a>
            </li>


            <li class="treeview menu-open">
                <a href="_hom.php">
                    <i class="fa fa-home" aria-hidden="true"></i>
                    <span>Home</span>
                    <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                </a>
                <ul class="treeview-menu" style="">
                    <li><a href="_hom.php"><i class="fa fa-home" aria-hidden="true"></i>Home</a></li>
                    <li class="active"><a href="_slider_home.php"><i class="fa fa-home" aria-hidden="true"></i>Slider Home</a></li>
                    <li class="active"><a href="_about.php"><i class="fa fa-circle-o"></i> About</a></li>
                    <li class="active"><a href="_slider_about.php"><i class="fa fa-circle-o"></i> Slider about</a></li>
                </ul>
            </li>


            <li class="treeview menu-open">
                <a href="_dehydration.php">
                    <i class="fa fa-h-square" aria-hidden="true"></i><span>Dyhydration</span>
                    <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                </a>
                <ul class="treeview-menu" style="">
                    <li><a href="_dehydration.php"><i class="fa fa-h-square" aria-hidden="true"></i>Dyhydration</a></li>
                    <li class="active"><a href="_dehydration_block.php"><i class="fa fa-h-square" aria-hidden="true"></i>Dyhydration_block</a></li>
                </ul>
            </li>

            <li>
                <a href="_Kidsuslite.php">
                    <i class="fa fa-child" aria-hidden="true"></i><span>Kids Us Lite</span>
                    <span class="pull-right-container">
            </span>
                </a>

            </li>
            <li>
                <a href="_contact_us.php">
                    <i class="fa fa-mobile" aria-hidden="true"></i><span>Contact Us</span>
                    <span class="pull-right-container">
            </span>
                </a>
            </li>
            <li>
                <a href="..\index.php">
                    <i class="fa fa-globe" aria-hidden="true"></i><span>Visit Your Website</span></a>
            </li>
        </ul>
    </section>
    <!-- /.sidebar -->
</aside>
