<?php
include 'connection.php';
include 'includes/temp/leftSideBar.php';
include 'includes/temp/header.php';
?>
<?php
if(isset($_POST['submit'])) {
    $id         = $_POST['id']  ;
    $title  = $_POST['title'];
    $mobile  = $_POST['mobile'];
    $name  = $_POST['name'];

    $stmt = $con->prepare("UPDATE block_header SET title = ?,mobile = ?,name = ?   WHERE id = ?");
    $stmt->execute(array($title, $mobile, $name, $id));
//    header('Location: _hom.php');
    echo"<script>window.location.href = '_block_header.php'; </script>";

}
?>


<style>
    /*.btn-success {*/
        /*background-color: #00a65a;*/
        /*border-color: #008d4c;*/
        /*position: relative;*/
        /*top: 171px;*/
        /*width: 26%;*/
        /*left: 66%;*/
    /*}*/
</style>


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Block Header
        </h1>
        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <!-- /.box -->

                    <div class="box">
                        <div class="box-header">
                            <h3 class="box-title">Update Block header</h3>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">

                            <table id="example1" class="table table-bordered table-striped">
                                <tr class="top" style="font-weight: bold;color: #fff;background-color: #3c8dbc">
                                    <td>all</td>

                                    <td>Action</td>
                                </tr>

                                <tr>
                                    <?php

                                    $stmt = $con->prepare("SELECT * FROM block_header");
                                    $stmt->execute();
                                    $rows = $stmt->fetchAll();

                                    foreach ($rows as $row){
                                    ?>

                                    <td>
                                        <form method="POST" action="<?php echo $_SERVER['PHP_SELF']?>">
                                            <input type="hidden" name="id" value="<?php echo $row['id'] ?>">
                                            <input type="text" name="title" value="<?php echo $row['title']?>">
                                            <input type="text" name="mobile" value="<?php echo $row['mobile']?>">
                                            <input type="text" name="name" value="<?php echo $row['name']?>">

                                    </td>
                                    <td style="">
                                        <input type="submit" name="submit" class="btn btn-success" value="Update">
                                    </td>
                                </tr>
                                </form>

                                <?php   }

                                ?>

                            </table>


                        </div>
                        <!-- /.box-body -->
                    </div>
                    <!-- /.box -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </section>

    </section>

</div>

<!-- /.content -->

<!-- Control Sidebar -->

<div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->
<?php
include 'includes/temp/footer.php'
?>

</body>
</html>
