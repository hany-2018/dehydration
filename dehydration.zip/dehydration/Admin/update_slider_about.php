<?php
include 'connection.php';
include 'includes/temp/leftSideBar.php';
include 'includes/temp/header.php';
?>
<?php
//if (isset($_GET ['id']) && !empty($_GET['id'])) {
//$id = $_GET['id'];
//?>

<?php
if (isset($_POST['submit'])) {
    $id = $_POST['id'];
    $title = $_POST['title'];
    $paragraph = $_POST['paragraph'];

    $image = $_FILES['image']['name'];
    $tmp_dir = $_FILES['image']['tmp_name'];
    $image_size = $_FILES['image']['size'];

    $upload_dir = 'uploads/slider/';
    $imgExt = strtolower(pathinfo($image, PATHINFO_EXTENSION));
    $valid_extension = array('jpeg', 'jpg', 'png', 'gif');

    $pic_Name = $image;
    move_uploaded_file($tmp_dir, $upload_dir.$pic_Name);

//    unlink($upload_dir . $image['fileToUpload']);


    $stmt = $con->prepare("UPDATE about_slider SET image = ?,title = ? , paragraph = ? WHERE id = ?");
    $stmt->execute(array($image, $title, $paragraph, $id));
//    header('Location: _hom.php');

        echo "<script>window.location.href = '_slider_about.php?'; </script>";

}
?>


<style>
    .btn-success {
        background-color: #00a65a;
        border-color: #008d4c;
        position: relative;
        top: 118px;
        font-weight: bold;
    }

    /*.button, input, select, textarea {*/
    /*width: 26%;*/
    /*}*/

</style>


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Update About Slider
        </h1>
        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <!-- /.box -->

                    <div class="box">
                        <div class="box-header">
                            <h3 class="box-title">About Slider</h3>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">

                            <table id="example1" class="table table-bordered table-striped">
                                <tr class="top" style="font-weight: bold;color: #fff;background-color: #3c8dbc">
                                    <td class="text-center" style="width:15%;">Image</td>
                                    <td class="text-center">Title</td>
                                    <td class="text-center">Paragraph</td>
                                    <td class="text-center">Action</td>
                                </tr>

                                <tr>
                                    <?php
                                    $stmt = $con->prepare("SELECT * FROM about_slider WHERE id = ?");
                                    $stmt->execute(array($_GET['id']));
                                    $rows = $stmt->fetchAll();
                                    //                                    print_r($rows);

                                    foreach ($rows as $row){
                                    ?>

                                    <td>
                                        <form method="POST" action="<?php echo $_SERVER['PHP_SELF'] ?>"
                                              enctype="multipart/form-data">
                                            <input type="hidden" name="id" value="<?php echo $row['id'] ?>">

                                            <!--                                            image-->

                                            <img src="uploads/slider/<?php echo $row['image'] ?>" alt=""
                                                 width="130" height="90px" class="img-rounded">


                                            <p style="font-weight: bold;color: #3c8dbc;font-size: 12px">Select image to upload:</p>
                                            <input type="file" name="image" accept="*/image"
                                            >

                                    </td>
                                    <td width="160px">
                                        <textarea rows="7" name="title"><?php echo $row['title'] ?></textarea>
                                    </td>
                                    <td>
                                        <textarea rows="7" name="paragraph"><?php echo $row['paragraph'] ?></textarea>
                                    </td>
                                    <td>
                                        <input type="submit" name="submit" class="btn btn-success" value="Update">
                                    </td>
                                </tr>

                                </form>

                                <!--                                --><?php }

                                //                                ?>
                                <?php

                                // }
                                ?>

                            </table>


                        </div>
                        <!-- /.box-body -->
                    </div>
                    <!-- /.box -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </section>

    </section>

</div>

<!-- /.content -->

<!-- Control Sidebar -->
<!-- /.control-sidebar -->
<!-- Add the sidebar's background. This div must be placed
     immediately after the control sidebar -->
<div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->
<?php
include 'includes/temp/footer.php'
?>
<!-- jQuery 3 -->
<!--<script src="bower_components/jquery/dist/jquery.min.js"></script>-->
<!--<!-- Bootstrap 3.3.7 -->-->
<!--<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>-->
<!--<!-- FastClick -->-->
<!--<script src="bower_components/fastclick/lib/fastclick.js"></script>-->
<!--<!-- AdminLTE App -->-->
<!--<script src="dist/js/adminlte.min.js"></script>-->
<!--<!-- AdminLTE for demo purposes -->-->
<!--<script src="dist/js/demo.js"></script>-->
</body>
</html>
