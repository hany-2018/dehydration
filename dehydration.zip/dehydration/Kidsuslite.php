<?php
include_once 'Admin/connection.php';

include_once 'includes/temp/header.php';
?>

    <!-- Content -->
    <div class="page-content bg-white">
    <!-- inner page banner -->
    <div class="dez-bnr-inr dez-accordion" style="background-image:url(Admin/uploads/kiduslite/<?php

    $stmt = $con->prepare("SELECT image FROM kidsuslite WHERE id = 1");
    $stmt->execute();
    $about_heading = $stmt->fetch();
    print_r($about_heading[0]);
    ?>)"


        <div class="container">
            <div class="dez-bnr-inr-entry">
                <!--<h1 class="text-white">Kids Us Lite</h1>-->
            </div>
        </div>
    </div>
    <!-- inner page banner END -->
    <!-- contact area -->
    <div class="content-area">
    <!-- Product details -->
    <div class="container woo-entry">
    <div class="row m-b30">
        <div class="blog-post blog-md date-style-2">
            <div class="col-md-4 col-sm-4 m-b30">
                <?php
                $stmt = $con->prepare("SELECT paragraph FROM kidsuslite WHERE id = 1");
                $stmt->execute();
                $about_heading = $stmt->fetch();
                print_r($about_heading[0]);
                ?>
                <br><br>
                <p style="color: #3396d1; font-weight: bold">

                    <?php
                    $stmt = $con->prepare("SELECT title FROM kidsuslite WHERE id = 2");
                    $stmt->execute();
                    $about_heading = $stmt->fetch();
                    print_r($about_heading[0]);
                    ?>

                </p>
                <p>

                    <?php
                    $stmt = $con->prepare("SELECT paragraph FROM kidsuslite WHERE id = 2");
                    $stmt->execute();
                    $about_heading = $stmt->fetch();
                    print_r($about_heading[0]);
                    ?>

                </p>
            </div>
            <div class="col-md-4 col-sm-4 m-b30">
                <img src="Admin/uploads/kiduslite/<?php
                $stmt = $con->prepare("SELECT image FROM kidsuslite WHERE id = 4");
                $stmt->execute();
                $about_heading = $stmt->fetch();
                print_r($about_heading[0]);
                ?>" style="height: 140px" width="100px" height="145px">

                <img src="Admin/uploads/kiduslite/<?php
                $stmt = $con->prepare("SELECT image FROM kidsuslite WHERE id = 6");
                $stmt->execute();
                $about_heading = $stmt->fetch();
                print_r($about_heading[0]);
                ?>" style="max-width: 78%" width="245px" height="145px">
                <p class="m-b10">

                    <?php
                    $stmt = $con->prepare("SELECT paragraph FROM kidsuslite WHERE id = 3");
                    $stmt->execute();
                    $about_heading = $stmt->fetch();
                    print_r($about_heading[0]);
                    ?>

                </p><br><br>
            </div>
            <div class="row">
                <div class="col-md-4 col-sm-4 m-b30">


                    <p style="color: #3396d1; font-weight: bold">


                        <?php
                        $stmt = $con->prepare("SELECT title FROM kidsuslite WHERE id = 4");
                        $stmt->execute();
                        $about_heading = $stmt->fetch();
                        print_r($about_heading[0]);
                        ?>

                    </p>
                    <p>
                        <?php
                        $stmt = $con->prepare("SELECT paragraph FROM kidsuslite WHERE id = 4");
                        $stmt->execute();
                        $about_heading = $stmt->fetch();
                        print_r($about_heading[0]);
                        ?>
                    </p>
                </div>
            </div>


            <div class="col-md-4 col-sm-4 m-b30">


                <p style="color: #3396d1; font-weight: bold">


                    <?php
                    $stmt = $con->prepare("SELECT title FROM kidsuslite WHERE id = 6");
                    $stmt->execute();
                    $about_heading = $stmt->fetch();
                    print_r($about_heading[0]);
                    ?>

                </p>

                <p class="m-b10">
                    <?php
                    $stmt = $con->prepare("SELECT paragraph FROM kidsuslite WHERE id = 6");
                    $stmt->execute();
                    $about_heading = $stmt->fetch();
                    print_r($about_heading[0]);
                    ?>
                </p>


            </div>

            <div class="col-xs-8">
                <!--<div class="dez-post-text">-->
                <img src="Admin/uploads/kiduslite/<?php
                $stmt = $con->prepare("SELECT image FROM kidsuslite WHERE id = 2");
                $stmt->execute();
                $about_heading = $stmt->fetch();
                print_r($about_heading[0]);
                ?>" alt=""width="971px" height="437px">
                <!--</div>-->
            </div>

            <div class="col-sm-offset-1 col-sm-10">
                <!--<div class="dez-post-text">-->
                <img src="Admin/uploads/kiduslite/<?php
                $stmt = $con->prepare("SELECT image FROM kidsuslite WHERE id = 3");
                $stmt->execute();
                $about_heading = $stmt->fetch();
                print_r($about_heading[0]);
                ?>" alt="" width="1349px" height="662px">
                <!--</div>-->
            </div>
        </div>
    </div>

    <!-- Footer -->
<?php
include_once 'includes/temp/footer.php'
?>