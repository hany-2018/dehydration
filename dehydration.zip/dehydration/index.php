<?php
include_once 'Admin/connection.php';
include_once 'includes/temp/header.php';
?>

<!-- Testimoniay  Testimoniay  Testimoniay  Testimoniay  Testimoniay -->
<div class="section-full owl-dots-style bg-img-fix md-testimonial">
    <div class="row">
        <div class="container-fluid">
            <div class="section-content col-md-6 overlay-primary-dark content-inner-1 bg-img-fix "
                 style="background-image:url(Admin/uploads/bg9.jpg);">
                <!--test quote genral manager-->
<!--                start home slider-->
                <div class="testimonial-six relative z-index2">
                    <!--slide one-->
                    <div class="item">
                        <div class="testimonial-1 testimonial-bg">
                            <!--<div class="testimonial-pic quote-left radius shadow"><img-->
                                    <!--src="images/testimonials/pic1.jpg" width="100" height="100" alt=""></div>-->
                            <div class="testimonial-text">
                                <img src="Admin/uploads/slider/<?php
                                            $stmt = $con->prepare("SELECT image FROM home_slider WHERE id = 1");
                                            $stmt->execute();
                                            $about_heading = $stmt->fetch();
                                            print_r($about_heading[0]);
                                ?>" alt="" style="border-top-left-radius: 10%;border-bottom-right-radius: 10%;
border-right: 2px solid #fff;border-bottom: 2px solid #fff">
                            </div>
                            <!--<div class="testimonial-detail"><strong class="testimonial-name">David Matin</strong> <span-->
                                    <!--class="testimonial-position">Student</span></div>-->
                        </div>
                    </div>
                    <!--slide two-->
                    <div class="item">
                        <div class="testimonial-1 testimonial-bg">
                            <!--<div class="testimonial-pic quote-left radius shadow"><img-->
                                    <!--src="images/testimonials/pic2.jpg" width="100" height="100" alt=""></div>-->
                            <div class="testimonial-text">
                                <img src="Admin/uploads/slider/<?php
                                $stmt = $con->prepare("SELECT image FROM home_slider WHERE id = 2");
                                $stmt->execute();
                                $about_heading = $stmt->fetch();
                                print_r($about_heading[0]);
                                ?>" alt=""  style="border-top-left-radius: 10%;border-bottom-right-radius: 10%;
border-right: 2px solid #fff;border-bottom: 2px solid #fff">
                            </div>
                            <!--<div class="testimonial-detail"><strong class="testimonial-name">David Matin</strong> <span-->
                                    <!--class="testimonial-position">Student</span></div>-->
                        </div>
                    </div>
                    <!--slide three-->
                    <div class="item">
                        <div class="testimonial-1 testimonial-bg">
                            <!--<div class="testimonial-pic quote-left radius shadow"><img-->
                                    <!--src="images/testimonials/pic3.jpg" width="100" height="100" alt=""></div>-->
                            <div class="testimonial-text">
                                <img src="Admin/uploads/slider/<?php
                                $stmt = $con->prepare("SELECT image FROM home_slider WHERE id = 3");
                                $stmt->execute();
                                $about_heading = $stmt->fetch();
                                print_r($about_heading[0]);
                                ?>" alt=""  style="border-top-left-radius: 10%;border-bottom-right-radius: 10%;
border-right: 1px solid #fff;border-bottom: 1px solid #fff">
                            </div>
                            <!--<div class="testimonial-detail"><strong class="testimonial-name">David Matin</strong> <span-->
                                    <!--class="testimonial-position">Student</span></div>-->
                        </div>
                    </div>

                    <!--slide four-->
                    <div class="item">
                        <div class="testimonial-1 testimonial-bg">
                            <!--<div class="testimonial-pic quote-left radius shadow"><img-->
                            <!--src="images/testimonials/pic3.jpg" width="100" height="100" alt=""></div>-->
                            <div class="testimonial-text">
                                <img src="Admin/uploads/slider/<?php
                                $stmt = $con->prepare("SELECT image FROM home_slider WHERE id = 4");
                                $stmt->execute();
                                $about_heading = $stmt->fetch();
                                print_r($about_heading[0]);
                                ?>" alt=""  style="border-top-left-radius: 10%;border-bottom-right-radius: 10%;
border-right: 1px solid #fff;border-bottom: 1px solid #fff">
                            </div>
                            <!--<div class="testimonial-detail"><strong class="testimonial-name">David Matin</strong> <span-->
                            <!--class="testimonial-position">Student</span></div>-->
                        </div>
                    </div>

                    <!--slide five-->
                    <div class="item">
                        <div class="testimonial-1 testimonial-bg">
                            <!--<div class="testimonial-pic quote-left radius shadow"><img-->
                            <!--src="images/testimonials/pic3.jpg" width="100" height="100" alt=""></div>-->
                            <div class="testimonial-text">
                                <img src="Admin/uploads/slider/<?php
                                $stmt = $con->prepare("SELECT image FROM home_slider WHERE id = 5");
                                $stmt->execute();
                                $about_heading = $stmt->fetch();
                                print_r($about_heading[0]);
                                ?>" alt=""  style="border-top-left-radius: 10%;border-bottom-right-radius: 10%;
border-right: 1px solid #fff;border-bottom: 1px solid #fff">
                            </div>
                            <!--<div class="testimonial-detail"><strong class="testimonial-name">David Matin</strong> <span-->
                            <!--class="testimonial-position">Student</span></div>-->
                        </div>
                    </div>


                </div>
            </div>

            <!--<div class="container-fluid" style="display: inline-block;">-->
            <div class="section-content col-md-6 content-inner-1 bg-img-fix "
                 style="display: inline-block; background-image:url(images/background/bg9.jpg);">
            <div class="manager" style="display:inline-block;opacity: 1">
                <h2 class="text-center" style=" background-color: #fff">

                    <?php
                    $stmt = $con->prepare("SELECT heading FROM home");
                    $stmt->execute();
                    $about_heading = $stmt->fetch();
                    print_r($about_heading[0]);
                    ?>

                </h2>
                <blockquote>

                    <?php
                    $stmt = $con->prepare("SELECT quotes FROM home");
                    $stmt->execute();
                    $about_heading = $stmt->fetch();
                    print_r($about_heading[0]);
                    ?>

                </blockquote>
                <code>

                    <?php
                    $stmt = $con->prepare("SELECT signature FROM home");
                    $stmt->execute();
                    $about_heading = $stmt->fetch();
                    print_r($about_heading[0]);
                    ?>

                </code><br>
                <code>General Manager</code> <br><br>
                <p style="background-color: #ffffff; font-size: 24px;line-height: 40px; text-align: center;letter-spacing: 1px">


                    <?php
                    $stmt = $con->prepare("SELECT paragraph FROM home");
                    $stmt->execute();
                    $about_heading = $stmt->fetch();
                    print_r($about_heading[0]);
                    ?>

                </p>
            </div>
            </div>
            </div>
            <!--</div> -->

        </div>


    </div>
</div>
<!-- Testimoniay END -->
<!-- Latest Blog -->
<div class="section-full bg-white content-inner">
    <div class="container">
        <div class="section-head text-center ">
            <h3 class="h3 text-uppercase">About <span class="text-primary">Us</span></h3>
            <p>

                <?php
                $stmt = $con->prepare("SELECT paragraph FROM about");
                $stmt->execute();
                $about_heading = $stmt->fetch();
                print_r($about_heading[0]);
                ?>

            </p>
        </div>

        <div class="container">
            <div id="myCarousel" class="carousel slide" data-ride="carousel">

                <!-- Wrapper for slides -->
                <div class="carousel-inner">
<!--                    start about slider-->
                    <div class="item active">
                        <img src="Admin/uploads/slider/<?php
                        $stmt = $con->prepare("SELECT image FROM about_slider WHERE id = 1");
                        $stmt->execute();
                        $about_heading = $stmt->fetch();
                        print_r($about_heading[0]);
                        ?>">
                        <div class="carousel-caption">
                            <h3 class="text-left vision">

                                <?php
                                $stmt = $con->prepare("SELECT title FROM about_slider");
                                $stmt->execute();
                                $about_heading = $stmt->fetch();
                                print_r($about_heading[0]);
                                ?>

                            </h3>
                                    <div class="detail col-md-pull-3 col-md-6">
<!--                               <p>Provide the market with healthy products with superior quality</p>-->
<!--                               <p>Satisfy the  customers’ needs with high  quality products that enrich customers’ lives </p>-->
<!--                               <p>	Developing, manufacturing and marketing novel products improve the life of the human and make life more easy and interesting  </p>-->
                                        <?php
                                        $stmt = $con->prepare("SELECT paragraph FROM about_slider");
                                        $stmt->execute();
                                        $about_heading = $stmt->fetch();
                                        print_r($about_heading[0]);
                                        ?>
                        </div>
                        </div>
                    </div><!-- End Item -->

                    <div class="item">
                        <img src="Admin/uploads/slider/<?php
                        $stmt = $con->prepare("SELECT image FROM about_slider WHERE id = 2");
                        $stmt->execute();
                        $about_heading = $stmt->fetch();
                        print_r($about_heading[0]);
                        ?>">
                        <div class="carousel-caption">
                            <h3>

                                <?php
                                $stmt = $con->prepare("SELECT title FROM about_slider");
                                $stmt->execute();
                                $about_heading = $stmt->fetch();
                                print_r($about_heading[0]);
                                ?>

                            </h3>
                            <div class="detail col-md-pull-3 col-md-6">

<!--                                <p>Our goal is to provide the Gulf with superior brands that help people manage their own health and make their life easier and interesting  </p>-->
<!--                                <p>To be the leading health care company in Saudi Arabia and other Gulf countries</p>-->

                                <?php
                                $stmt = $con->prepare("SELECT paragraph FROM about_slider");
                                $stmt->execute();
                                $about_heading = $stmt->fetch();
                                print_r($about_heading[0]);
                                ?>

                            </div>
                        </div>
                    </div><!-- End Item -->


                </div><!-- End Carousel Inner -->


                <ul class="nav nav-pills nav-justified">
                    <li data-target="#myCarousel" data-slide-to="0" class="active"><a href="#">About<small>Vision</small></a></li>
                    <li data-target="#myCarousel" data-slide-to="1"><a href="#">About<small>Mission</small></a></li>
                    <!--<li data-target="#myCarousel" data-slide-to="2"><a href="#">Portfolio<small>Lorem ipsum dolor sit</small></a></li>-->
                    <!--<li data-target="#myCarousel" data-slide-to="3"><a href="#">Services<small>Lorem ipsum dolor sit</small></a></li>-->
                </ul>


            </div><!-- End Carousel -->
        </div>

          </div>
</div>
<!-- Latest Blog END -->
<?php
include_once 'includes/temp/footer.php'
?>