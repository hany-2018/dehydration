<?php
include_once 'Admin/connection.php';

include_once 'includes/temp/header.php'
?>

<?php
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $name = filter_var($_POST['name'],FILTER_SANITIZE_STRING);
    $mail= filter_var($_POST['email'],FILTER_SANITIZE_EMAIL);
    $phone = filter_var($_POST['Phone'],FILTER_SANITIZE_NUMBER_INT);
    $subject = filter_var($_POST['Subject'],FILTER_SANITIZE_STRING);
    $msg = filter_var($_POST['Message'],FILTER_SANITIZE_STRING);
    $stmt = $con->prepare("INSERT INTO contact_us (name,mail,phone,subject,msg)
                  VALUES(:zname,:zmail,:zphone,:zsub,:zmsg)");
    $stmt->execute(array(
        'zname' =>$name,
        'zmail' =>$mail,
        'zphone'=>$phone,
        'zsub'  =>$subject,
        'zmsg'  =>$msg,
    ));
}
?>
    <!-- About Company -->
<div class="section-full content-inner bg-white">
    <div class="container">
        <div class="section-content">
            <div class="row">
                <div class="col-md-7">
                    <h3 class="h3 text-uppercase">Contact<span class="text-primary"> Us</span></h3><br><br><br>

                    <div class="clearfix bg-primary text-white p-a30 about-appoint">
                        <div class="dzFormMsg"></div>
                        <form method="POST" class="dzForm" action="<?php echo $_SERVER['PHP_SELF']?>">
                            <input type="hidden" value="Contact" name="dzToDo" >
                            <div class="row">
<!--                                <div class="col-md-6">-->
<!--                                    <div class="form-group">-->
<!--                                        <div class="input-group">-->
<!--                                            <input name="name" type="text" required class="form-control" placeholder="Your Name" id="name">-->
<!--                                        </div>-->
<!--                                    </div>-->
<!--                                </div>-->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="input-group">
                                            <input name="email" type="email" class="form-control" required  placeholder="Your Email Id" id="mail">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="input-group">
                                            <input name="Phone" type="text" required class="form-control" placeholder="Phone" id="phone">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="input-group">
                                            <input name="Subject" type="text" required class="form-control" placeholder="Subject" id="subject">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <div class="input-group">
                                            <textarea name="Message" rows="4" class="form-control" required placeholder="Your Message..." id="msg"></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <button name="btn_add" type="submit" value="Submit" class="site-button white outline"> <span>Send Your Data</span> </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="dez-thum disnone-sm"><img src="Admin/uploads/<?php
                        $stmt = $con->prepare("SELECT image FROM contact_us WHERE id = 1");
                        $stmt->execute();
                        $about_heading = $stmt->fetch();
                        print_r($about_heading[0]);
                        ?>" alt=""></div>
                </div>
            </div>
        </div>
    </div>
</div>




<!-- Footer -->
<?php
include_once 'includes/temp/footer.php'
?>