<!---->
<!--/**-->
<!-- * Created by PhpStorm.-->
<!-- * User: enjoy ur time-->
<!-- * Date: 6/2/2018-->
<!-- * Time: 7:37 AM-->
<!-- */-->


<!-- Footer -->
<footer class="site-footer footer-white">
    <div class="footer-top">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6 footer-col-4">
                    <div class="widget widget_about">
                        <div class="logo-footer"><img alt="" src="images/logo.gif"></div>
                        <p><strong>

                                <?php
                                $stmt = $con->prepare("SELECT title FROM footer_first ");
                                $stmt->execute();
                                $about_heading = $stmt->fetch();
                                print_r($about_heading[0]);
                                ?>

                            </strong>

                            <?php
                            $stmt = $con->prepare("SELECT paragraph FROM footer_first ");
                            $stmt->execute();
                            $about_heading = $stmt->fetch();
                            print_r($about_heading[0]);
                            ?>
                        </p>
                        <ul class="dez-social-icon border">
                            <li><a class="fa fa-facebook" href="#"></a></li>
                            <li><a class="fa fa-twitter" href="#"></a></li>
                            <li><a class="fa fa-linkedin" href="#"></a></li>
                            <li><a class="fa fa-facebook" href="#"></a></li>
                        </ul>
                    </div>
                </div>

                <div class="col-md-4 col-sm-6 footer-col-6">
                    <div class="widget widget_services">
                        <h4 class="m-b15 text-uppercase">Our services</h4>
                        <div class="dez-separator bg-primary"></div>
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li><a href="dehydration.php">dehydration</a></li>
                            <li><a href="Kidsuslite.php">Kids Us Lite</a></li>
                            <li><a href="contact_us.php">Contact Us</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 footer-col-6">
                    <div class="widget widget_getintuch">
                        <h4 class="m-b15 text-uppercase">Contact us</h4>
                        <div class="dez-separator bg-primary"></div>
                        <ul>
                            <li><a href="https://www.facebook.com/Kidsuslite/"><i class="fa fa-facebook"></i><strong>Facebook</strong>Visit Now</a></li>
                            <li><a href="https://twitter.com/kidsuslite"><i class="fa fa-twitter"></i><strong>Twitter</strong>Visit Now</a></li>
                            <li><a href="https://www.instagram.com/kidsuslite/"><i class="fa fa-instagram"></i><strong>instagram</strong> Visit Now</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- footer bottom part -->
    <div class="footer-bottom ">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center"><span>© copyright 2018  by Dehydration. All Rights Reserved.</span>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Footer END-->
<!-- scroll top button -->
<button class="scroltop fa fa-chevron-up"></button>
</div>
<!-- JavaScript  files ========================================= -->
<script src="js/jquery.min.js"></script>
<!-- jquery.min js -->
<script src="js/bootstrap.min.js"></script>
<!-- bootstrap.min js -->
<script src="js/bootstrap-select.min.js"></script>
<!--&lt;!&ndash; Form js &ndash;&gt;-->
<script src="js/jquery.bootstrap-touchspin.js"></script>
<!--&lt;!&ndash; Form js &ndash;&gt;-->
<script src="js/magnific-popup.js"></script>
<!--&lt;!&ndash; magnific-popup js &ndash;&gt;-->
<script src="js/waypoints-min.js"></script>
<!--&lt;!&ndash; waypoints js &ndash;&gt;-->
<script src="js/counterup.min.js"></script>
<!--&lt;!&ndash; counterup js &ndash;&gt;-->
<script src="js/imagesloaded.js"></script>
<!--&lt;!&ndash; masonry  &ndash;&gt;-->
<script src="js/masonry-3.1.4.js"></script>
<!--&lt;!&ndash; masonry  &ndash;&gt;-->
<script src="js/masonry.filter.js"></script>
<!--&lt;!&ndash; masonry  &ndash;&gt;-->
<script src="js/owl.carousel.js"></script>
<!--&lt;!&ndash; OWL  Slider  &ndash;&gt;-->
<script src="js/custom.js"></script>
<!--&lt;!&ndash; custom fuctions  &ndash;&gt;-->
<script src="js/dz.carousel.js"></script>
<!--&lt;!&ndash; sortcode fuctions  &ndash;&gt;-->
<!--<script  src="js/switcher.min.js"></script>-->
<!--&lt;!&ndash; switcher fuctions  &ndash;&gt;-->
<script src="js/dz.ajax.js"></script>
<!--&lt;!&ndash; contact-us js &ndash;&gt;-->
<!--&lt;!&ndash; revolution JS FILES &ndash;&gt;-->
<!--<script src="js/jquery.themepunch.tools.min.js"></script>-->
<!--<script src="js/jquery.themepunch.revolution.min.js"></script>-->
<script src="js/rev.slider.js"></script>
<script src="js/custom.js"></script>
<script>
jQuery(document).ready(function () {
    'use strict';
    dz_rev_slider_3();
});
    /*ready*/
</script>
</body>

</html>
