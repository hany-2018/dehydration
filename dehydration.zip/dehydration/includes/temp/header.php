<!DOCTYPE html>
<!--[if IE 7 ]>
<html lang="en-gb" class="isie ie7 oldie no-js"> <![endif]-->
<!--[if IE 8 ]>
<html lang="en-gb" class="isie ie8 oldie no-js"> <![endif]-->
<!--[if IE 9 ]>
<html lang="en-gb" class="isie ie9 no-js"> <![endif]-->
<!-- Meta -->
<html lang="en">
<!-- Mirrored from medico.dexignlab.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 23 May 2018 19:42:49 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content=""/>
    <meta name="author" content=""/>
    <meta name="robots" content=""/>
    <meta name="description" content=""/>
    <meta name="format-detection" content="telephone=no">
    <!-- Favicons Icon -->
    <link rel="icon" href="images/logo.ico" type="image/x-icon"/>
    <link rel="shortcut icon" type="image/x-icon" href="images/logo.gif"/>
    <!-- Page Title Here -->
    <title>Modern Arab Health</title>
    <!-- Mobile Specific -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.min.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
    <!-- Stylesheets -->
    <link rel="stylesheet" type="text/css" href="css/fontawesome/css/font-awesome.min.css"/>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">

    <!--<link rel="stylesheet" type="text/css" href="css/flaticon/flaticon.css" />-->
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-select.min.css">
    <link rel="stylesheet" type="text/css" href="css/magnific-popup.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link class="skin" rel="stylesheet" type="text/css" href="css/skin/skin-1.css">
    <link rel="stylesheet" type="text/css" href="css/templete.css">
    <!--<link rel="stylesheet" type="text/css" href="css/switcher.css"/>-->
    <!-- Revolution Slider Css -->
    <link rel="stylesheet" type="text/css" href="plugins/revolution/revolution/css/settings.css">
    <!-- Revolution Navigation Style -->
    <link rel="stylesheet" type="text/css" href="plugins/revolution/revolution/css/navigation.css">


    <link rel="stylesheet" type="text/css" href="css/main.css">

    <!-- Google fonts -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900|Open+Sans:300,400,600,700,800|Roboto:100,300,400,500,700,900"
          rel="stylesheet">
</head>

<body>
<!-- header -->
<header class="site-header header header-style-4 style-1">
    <div class="bg-white">
        <div class="container header-contant-block">
            <div class="row">
                <div class="col-md-4">
                    <div class="logo-header "><a href="index.php"><img src="Admin/uploads/logo.gif" width="193" height="89"
                                                                          alt=""></a></div>
                </div>
                <div class="col-md-8">
                    <ul class="contact-info style-1 clearfix text-primary">
                        <li>
                            <h6 class="text-primary"><i class="fa fa-phone"></i>

                                <?php
                                $stmt = $con->prepare("SELECT title FROM block_header WHERE id = 1");
                                $stmt->execute();
                                $about_heading = $stmt->fetch();
                                print_r($about_heading[0]);
                                ?>

                            </h6><span>


                                <?php
                                $stmt = $con->prepare("SELECT name FROM block_header WHERE id = 1");
                                $stmt->execute();
                                $about_heading = $stmt->fetch();
                                print_r($about_heading[0]);
                                ?>

                            </span>
                            <span>


                                <?php
                                $stmt = $con->prepare("SELECT mobile FROM block_header WHERE id = 1");
                                $stmt->execute();
                                $about_heading = $stmt->fetch();
                                print_r($about_heading[0]);
                                ?>

                            </span>

                        </li>
                        <li>
                            <h6 class="text-primary"><i class="fa fa-envelope-o"></i>


                                <?php
                                $stmt = $con->prepare("SELECT title FROM block_header WHERE id = 2");
                                $stmt->execute();
                                $about_heading = $stmt->fetch();
                                print_r($about_heading[0]);
                                ?>

                                <div>


                                    <?php
                                    $stmt = $con->prepare("SELECT name FROM block_header WHERE id = 2");
                                    $stmt->execute();
                                    $about_heading = $stmt->fetch();
                                    print_r($about_heading[0]);
                                    ?>

                                </div> </h6>
                            <span>


                                <?php
                                $stmt = $con->prepare("SELECT mobile FROM block_header WHERE id = 2");
                                $stmt->execute();
                                $about_heading = $stmt->fetch();
                                print_r($about_heading[0]);
                                ?>

                            </span>
                        </li>
                        <li>
                            <h6 class="text-primary"><i class="fa fa-phone"></i>


                                <?php
                                $stmt = $con->prepare("SELECT title FROM block_header WHERE id = 3");
                                $stmt->execute();
                                $about_heading = $stmt->fetch();
                                print_r($about_heading[0]);
                                ?>

                            </h6><span>


                                <?php
                                $stmt = $con->prepare("SELECT name FROM block_header WHERE id = 3");
                                $stmt->execute();
                                $about_heading = $stmt->fetch();
                                print_r($about_heading[0]);
                                ?>

                            </span>
                            <span>


                                <?php
                                $stmt = $con->prepare("SELECT mobile FROM block_header WHERE id = 3");
                                $stmt->execute();
                                $about_heading = $stmt->fetch();
                                print_r($about_heading[0]);
                                ?>

                            </span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- main header -->
    <div class="sticky-header main-bar-wraper">
        <div class="main-bar clearfix ">
            <div class="navigation-bar bg-primary">
                <div class="container clearfix">
                    <!-- website logo -->
                    <div class="logo-header mostion"><a href="index-2.html"><img src="images/logo.gif" width="193"
                                                                                 height="89" alt=""></a></div>
                    <!-- nav toggle button -->
                    <button data-target=".header-nav" data-toggle="collapse" type="button"
                            class="navbar-toggle collapsed"><span class="sr-only">Toggle navigation</span> <span
                            class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span>
                    </button>
                    <!-- extra nav -->
                    <div class="extra-nav">
                        <div class="extra-cell">
                            <button id="quik-search-btn" type="button" class="site-button white"><i
                                    class="fa fa-search"></i></button>
                        </div>
                    </div>
                    <!-- Quik search -->
                    <div class="dez-quik-search bg-primary">
                        <form action="#">
                            <input name="search" value="" type="text" class="form-control" placeholder="Type to search">
                            <span id="quik-search-remove"><i class="fa fa-remove"></i></span>
                        </form>
                    </div>
                    <!-- main nav -->
                    <div class="header-nav navbar-collapse collapse">
                        <ul class=" nav navbar-nav">
                            <li class="active"><a href="index.php">Home<i class="fa fa-chevron-down"></i></a></li>
                            <li><a href="dehydration.php">dehydration<i class="fa fa-chevron-down"></i></a></li>
                            <li><a href="Kidsuslite.php">Kids Us Lite<i class="fa fa-chevron-down"></i></a></li>
                            <li><a href="contact_us.php">Contact Us<i class="fa fa-chevron-down"></i></a></li>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- main header END -->
</header>
<!-- header END -->